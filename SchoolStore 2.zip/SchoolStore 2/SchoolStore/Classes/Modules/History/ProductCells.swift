//
//  ProductCells.swift
//  SchoolStore
//
//  Created by Heads on 08.10.2021.
//

import Foundation
import UIKit
import AutoLayoutSugar

final class ProductCells: UITableViewCell {
    
    private lazy var contentImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        
        return imageView
    }()
    
    private lazy var statusOfOrder: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
    }()
    
    private lazy var numberOfOrder: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
    }()
    
    private lazy var nameOfProduct: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
    }()
    
    private lazy var dateAdressOrder: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
    }()
    
    private lazy var addToCartButton: UIButton = {
        let button = UIButton()
     //   button.setImage(Asset.fieldEye.image, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        
        return button
    }()
    
    private lazy var separatorView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        
        return view
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    var model: String? {
        didSet {
            numberOfOrder.text = model
        }
    }
    
    private func setup() {
        selectionStyle = .none
        contentView.addSubview(contentImageView)
        contentView.addSubview(nameOfProduct)
        contentView.addSubview(statusOfOrder)
        contentView.addSubview(addToCartButton)
        contentView.addSubview(numberOfOrder)
        contentView.addSubview(dateAdressOrder)
        contentView.addSubview(separatorView)
        
        [contentImageView].forEach {
           $0.layer.borderWidth = 1
           $0.layer.borderColor = UIColor.blue.cgColor
        }
        
        contentImageView.top(16).left(16).bottom(16).width(112).height(112)
        
        numberOfOrder.top(16).left(to: .right(8), of: contentImageView).right(16)
        numberOfOrder.font = UIFont(name: "Roboto", size: 14.0)
        numberOfOrder.textColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        
        statusOfOrder.top(to: .bottom(8), of: numberOfOrder).left(to: .right(8), of: contentImageView).right(16)
        statusOfOrder.font = UIFont(name: "Roboto", size: 18.0)
        statusOfOrder.text = "В работе"
        statusOfOrder.textColor = UIColor(red: 0.298, green: 0.686, blue: 0.313, alpha: 0.87)
        
        nameOfProduct.top(to: .bottom(8), of: statusOfOrder).left(to: .right(8), of: contentImageView).right(16)
        nameOfProduct.font = UIFont(name: "Roboto", size: 16.0)
        nameOfProduct.text = "Nike"
        nameOfProduct.textColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        
        dateAdressOrder.top(to: .bottom(8), of: nameOfProduct).left(to: .right(8), of: contentImageView).right(16)
        dateAdressOrder.font = UIFont(name: "Roboto", size: 14.0)
        dateAdressOrder.text = """
                            Дата доставки:
                            Адрес доставки:
                            """
        dateAdressOrder.textColor = UIColor(red: 0.643, green: 0.643, blue: 0.643, alpha: 1.0)
        
        separatorView.bottom().left(16).right(16).height(1)
        separatorView.backgroundColor = UIColor.gray
    }
}
