//
//  ProductCell.swift
//  SchoolStore
//
//  Created by a1 on 06.10.2021.
//

import Foundation
import UIKit
import AutoLayoutSugar

final class ProductCell: UITableViewCell {
    
    private lazy var contentImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        
        return imageView
    }()
    
    private lazy var descriptionLabel: UILabel = {
        let label = UILabel()
       // label.font = UIFont(name: "Roboto", size: 30.0)
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
    }()
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
    }()
    
    private lazy var addToCartButton: UIButton = {
        let button = UIButton()
        let image = UIImage(systemName: "cart")
        button.setImage(image, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        
        return button
    }()
    
    private lazy var separatorView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        
        return view
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    var model: String? {
        didSet {
            titleLabel.text = model
        }
    }
    
    private func setup() {
        selectionStyle = .none
        contentView.addSubview(contentImageView)
        contentView.addSubview(priceLabel)
        contentView.addSubview(descriptionLabel)
        contentView.addSubview(addToCartButton)
        contentView.addSubview(titleLabel)
        contentView.addSubview(separatorView)
        
        [contentImageView].forEach {
           $0.layer.borderWidth = 1
           $0.layer.borderColor = UIColor.blue.cgColor
        }
        
        contentImageView.top(16).left(16).bottom(16).width(112).height(112)
        
        titleLabel.top(16).left(to: .right(16), of: contentImageView).right(16)
        titleLabel.font = UIFont(name: "Roboto", size: 20.0)
        titleLabel.textColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        
        descriptionLabel.top(to: .bottom, of: titleLabel).left(to: .right(16), of: contentImageView).right(16)
        descriptionLabel.font = UIFont(name: "Roboto", size: 16.0)
        descriptionLabel.text = "Джерси"
        descriptionLabel.textColor = UIColor(red: 0.643, green: 0.643, blue: 0.643, alpha: 1.0)
        
        priceLabel.bottom(31).left(to: .right(16), of: contentImageView)
        priceLabel.font = UIFont(name: "Roboto", size: 20.0)
        priceLabel.text = "₽"
        priceLabel.textColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        
        addToCartButton.top(to: .top, of: priceLabel).bottom(31).left(to: .right(16), of: priceLabel).right(24)
        addToCartButton.titleLabel?.font = UIFont(name: "Roboto", size: 16.0)
        addToCartButton.setTitle(" Купить", for: .normal)
        addToCartButton.setTitleColor(UIColor(red: 0.0, green: 0.207, blue: 0.58, alpha: 1.0), for: .normal)
        
        separatorView.bottom().left(16).right(16).height(1)
        separatorView.backgroundColor = UIColor.gray
    }
}
