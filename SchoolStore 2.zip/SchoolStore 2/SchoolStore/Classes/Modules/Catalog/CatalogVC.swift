// \HxH School iOS Pass
// Copyright © 2021 Heads and Hands. All rights reserved.
//

import Foundation
import UIKit
import AutoLayoutSugar

final class CatalogVC: UIViewController {
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .plain)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.delegate = self
        tableView.separatorStyle = .none
        tableView.dataSource = self
        tableView.register(ProductCell.self, forCellReuseIdentifier: Self.productCellReuseId)
        
        return tableView
    }()
    
    static let productCellReuseId: String = ProductCell.description()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(tableView)
        tableView.top().left().right().bottom()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2, execute: { [weak self] in
            self?.items = [
                "Nike", "Puma", "Adidas", "Nike", "Nike"
            ]
            
            self?.tableView.reloadData()
        })
        
        
    }
    
    var items: [String] = []
}

extension CatalogVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        items.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) ->
    UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: Self.productCellReuseId, for: indexPath) as? ProductCell else {
                return UITableViewCell()
            }
            
        cell.model = items[indexPath.row]
        return cell
    }
    
    
}
