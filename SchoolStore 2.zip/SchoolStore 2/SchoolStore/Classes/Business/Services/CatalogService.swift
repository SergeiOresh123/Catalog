//
//  CatalogService.swift
//  SchoolStore
//
//  Created by Heads on 08.10.2021.
//

import Foundation

/*protocol CatalogService: AnyObject {
    func RequestProduct(fields: String, limit: String, offset: String, completion: ((Result<[Product], Error>) -> Void)?)
}

final class CatalogServiceImpl: CatalogService {
    
        init(networkProvider: NetworkProvider, dataService: DataService) {
        self.networkProvider = networkProvider
        self.dataService = dataService
    }
    
    typealias CatalogLoad = DataResponse<GetListOfProductResponse>

    func RequestProduct(fields: String, limit: String, offset: String, completion: ((Result<[Product], Error>) -> Void)?) {
        networkProvider.mock(CatalogRequest.listOfProducts) { [weak self] (result: Result<CatalogLoad, Error>) in
            switch result {
            case let .success(data):
                let pr = data.data.products
                completion?(Result.success(data))
            case let .failure(error):
                completion?(Result.failure(data))
            }
        }
    }
    
    private let networkProvider: NetworkProvider

    private let dataService: DataService
  
} */
