//
//  ProductBadge.swift
//  SchoolStore
//
//  Created by Heads on 08.10.2021.
//

import Foundation

struct ProductBadge: Decodable {
    
    let value: String
    let color: String

}
