//
//  CatalogResponse.swift
//  SchoolStore
//
//  Created by Heads on 08.10.2021.
//

import Foundation

struct GetListOfProductResponse: Decodable {
    let products: [Product]
}

struct GetDetailInfoResponse: Decodable {
    let product: Product
}
