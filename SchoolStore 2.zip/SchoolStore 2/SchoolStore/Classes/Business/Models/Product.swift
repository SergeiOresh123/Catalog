//
//  Product.swift
//  SchoolStore
//
//  Created by Heads on 08.10.2021.
//

import Foundation

struct Product: Decodable {
    
    let id: String
    let title: String
    let department: String
    let price: Int
    let preview: String
    let description: String
    let details: [String]
    let images: [String]
    let sizes: [ProductSize]
    let badge: ProductBadge
    
    
}
